package libraryService;

public interface LibraryDatabase {
	Book findBookByIsbn(String isbn);
}
