package libraryService;

import java.util.HashMap;

public class LibraryDatabaseStub implements LibraryDatabase {

	private HashMap<String, Book> books = new HashMap<>();

	public void addBook(Book book) {
		books.put(book.getIsbn(), book);
	}

	@Override
	public Book findBookByIsbn(String isbn) {
		return books.get(isbn);
	}
}
