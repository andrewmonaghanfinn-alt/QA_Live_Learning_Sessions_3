package libraryService;

public class Book {

	private String title;
	private String isbn;
	private boolean isAvailable;

	public Book(String title, String isbn) {
		this.title = title;
		this.isbn = isbn;
		this.isAvailable = true;
	}

	public String getTitle() {
		return title;
	}

	public String getIsbn() {
		return isbn;
	}

	public boolean isAvailable() {
		return isAvailable;
	}

	public void borrowBook() {
		if (!isAvailable) {
			throw new IllegalStateException("Book is already on loan.");
		}
		this.isAvailable = false;
	}

	public void returnBook() {
		if (isAvailable) {
			throw new IllegalStateException("Book was not on loan.");
		}
		this.isAvailable = true;
	}
}
