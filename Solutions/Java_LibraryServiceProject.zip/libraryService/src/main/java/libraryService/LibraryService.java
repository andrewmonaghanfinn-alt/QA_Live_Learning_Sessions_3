package libraryService;

public class LibraryService {

	private LibraryDatabase database;

	public LibraryService(LibraryDatabase database) {
		this.database = database;
	}

	public boolean borrowBook(String isbn, User user) {
		Book book = database.findBookByIsbn(isbn);

		if (book == null)
			throw new IllegalArgumentException("Book not found.");

		if (!book.isAvailable())
			return false;

		book.borrowBook();
		return true;
	}

	public boolean returnBook(String isbn, User user) {
		Book book = database.findBookByIsbn(isbn);

		if (book == null)
			throw new IllegalArgumentException("Book not found.");

		if (book.isAvailable())
			return false;

		book.returnBook();
		return true;
	}

	public boolean updateBookStatus(String isbn, boolean isAvailable) {
		Book book = database.findBookByIsbn(isbn);

		if (book == null)
			throw new IllegalArgumentException("Book not found.");

		if (isAvailable)
			book.returnBook();
		else
			book.borrowBook();

		return true;
	}
}
