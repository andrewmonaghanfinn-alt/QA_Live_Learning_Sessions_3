package libraryService;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class LibraryServiceTest {

    private LibraryDatabaseStub db;
    private LibraryService service;
    private User user;

    @BeforeEach
    public void setup() {
        db = new LibraryDatabaseStub();
        service = new LibraryService(db);
        user = new User("Alice", 1);

        db.addBook(new Book("Test Book", "123"));
    }

    @Test
    public void borrowBook_WhenAvailable_ShouldSucceed() {
        boolean result = service.borrowBook("123", user);

        assertTrue(result);
        assertFalse(db.findBookByIsbn("123").isAvailable());
    }

    @Test
    public void borrowBook_WhenAlreadyOnLoan_ShouldFail() {
        service.borrowBook("123", user);

        boolean result = service.borrowBook("123", user);

        assertFalse(result);
    }

    @Test
    public void returnBook_WhenOnLoan_ShouldSucceed() {
        service.borrowBook("123", user);

        boolean result = service.returnBook("123", user);

        assertTrue(result);
        assertTrue(db.findBookByIsbn("123").isAvailable());
    }

    @Test
    public void returnBook_WhenNotOnLoan_ShouldFail() {
        boolean result = service.returnBook("123", user);

        assertFalse(result);
    }

    @Test
    public void updateBookStatus_ShouldChangeAvailability() {
        service.updateBookStatus("123", false);
        assertFalse(db.findBookByIsbn("123").isAvailable());

        service.updateBookStatus("123", true);
        assertTrue(db.findBookByIsbn("123").isAvailable());
    }
}

